import json

def lambda_handler(event, context):
    # Event contains data from API Gateway
    body = event.get('body', '')
    response = {
        'statusCode': 200,
        'body': json.dumps({
            'message': 'Hello from Lambda',
            'input': body
        })
    }
    return response
